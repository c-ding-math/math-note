MathJax = {
    svg: { scale: 0.9 },
    tex: { inlineMath: [["$", "$"]]},
    options: { skipHtmlTags: ["script", "noscript", "style", "textarea", "pre"] }
};